<?php

namespace Modules\System\Events;

/**
 * 菜单链接
 */
class MenuUrl
{

    public function __construct()
    {
    }

}

