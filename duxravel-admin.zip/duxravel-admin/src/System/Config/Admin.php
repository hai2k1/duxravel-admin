<?php

return [
    'home' => env(
        'ADMIN_HOME',
        'admin.development'
    ),
];

