<?php
return [
    'system' => 1,
    'name' => 'Basic system',
    'auth' => 'DuxPHP',
    'id' => '753e34c0df9caf3318e485741f22514c',
    'desc' => 'system basic function module',
    'icon' => '',
];
