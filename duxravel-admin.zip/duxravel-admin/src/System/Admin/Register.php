<?php

namespace Modules\System\Admin;

/**
 * 注册用户
 * @package Modules\System\System
 */
class Register extends Common
{

    use \Duxravel\Core\Manage\Register;
}
