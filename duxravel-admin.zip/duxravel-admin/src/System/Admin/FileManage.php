<?php

namespace Modules\System\Admin;


class FileManage extends Common
{

    use \Duxravel\Core\Manage\FileManage;

}
