<?php

namespace Modules\System\Admin;

use Illuminate\Support\Facades\DB;
use Duxravel\Core\UI\Table;
use Duxravel\Core\UI\Widget;

class VisitorViews extends \Modules\System\Admin\Expend
{

    use \Duxravel\Core\Manage\Visitor;

}
