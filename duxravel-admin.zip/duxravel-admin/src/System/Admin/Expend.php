<?php

namespace Modules\System\Admin;

/**
 * Class Expend
 * @package Modules\System\System
 */
class Expend extends Common
{
    use \Duxravel\Core\Manage\Expend;
}
