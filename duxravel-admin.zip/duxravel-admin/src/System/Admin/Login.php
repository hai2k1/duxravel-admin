<?php

namespace Modules\System\Admin;

use Illuminate\Http\Request;

/**
 * 用户登录
 * @package Modules\System\System
 */
class Login extends Common
{

    use \Duxravel\Core\Manage\Login;

}
