<?php

namespace Modules\System\Admin;

class Role extends \Modules\System\Admin\Expend
{
    use \Duxravel\Core\Manage\Role;
}
