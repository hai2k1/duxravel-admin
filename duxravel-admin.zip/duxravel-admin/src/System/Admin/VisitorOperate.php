<?php

namespace Modules\System\Admin;

use Duxravel\Core\Manage\Operate;

class VisitorOperate extends \Modules\System\Admin\Expend
{

    public string $model = \Duxravel\Core\Model\VisitorOperate::class;

    use Operate;

}
