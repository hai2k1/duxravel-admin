<?php

namespace Modules\System\Admin;

use Duxravel\Core\Controllers\Controller;

class Common extends Controller
{
    use \Duxravel\Core\Manage\Common;
}
