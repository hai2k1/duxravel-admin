<?php

namespace Modules\System\Admin;


class Map extends Common
{

    use \Duxravel\Core\Manage\Map;

}
