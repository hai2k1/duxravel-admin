<?php

return [
    'system' => 1,
    'name' => 'Extension tool',
    'auth' => 'DuxPHP',
    'id' => '243640453797249024',
    'desc' => 'System extension tool function',
    'icon' => '',
];
